import pandas as pd
ratings=pd.read_csv("C:/Users/Dell/Desktop/ratings.csv")
movies=pd.read_csv("C:/Users/Dell/Desktop/movies.csv")
movies=movies.dropna()
ratings['rating'].fillna(ratings['rating'].mean())
ratings.dropna()
completedataset=pd.merge(movies,ratings,on='movieId')
completedataset=completedataset.drop(['timestamp'],axis='columns')
groupeddata=completedataset.groupby(['title'])['rating'].mean()

groupeddata1=completedataset.groupby(['title'])['rating'].count()
genreDataFrame=pd.DataFrame(movies['title'])
genreDataFrame['genre']=movies['genres']
recommendations=pd.DataFrame(groupeddata)
recommendations['no_of_ratings']=pd.DataFrame(groupeddata1)
trending=pd.merge(recommendations,genreDataFrame,on='title')
trending=trending.sort_values(['no_of_ratings'],ascending=False)
recommendations=recommendations.sort_values(['no_of_ratings'],ascending=False)
print(recommendations.head(15))
print(trending.head(15))

print("enter movie name(note: make sure to enter correct movie with date from the above list):")
name=input()
titlegroupby=trending.groupby('title')
print(titlegroupby)
genrevalue=''
condition=0

try:
    titlegroupby_value=titlegroupby.get_group(name)
   
except Exception as e:
    condition=1
    print("there is no movie name with check the spelling you have written if it is correct then there is no movie",name)
if(condition==0):
    genrevalue=titlegroupby_value['genre'].values

    genregroupby=trending.groupby('genre')
    genrelist=genregroupby.get_group(genrevalue[0])
    genrelist=genrelist.sort_values(['no_of_ratings'],ascending=False)
    finallist=genrelist.drop('genre',axis='columns')
    finallist=finallist.head(10)
    finallist=finallist.to_string(index=False)
    print(finallist)
